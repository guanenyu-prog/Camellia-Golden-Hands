import Foundation
import CoreMotion

/// 专门拦截 AirPods Pro / Max 头部旋转的高频传感器 (IMU)
/// 用于在“免摄像机”的环境下，提供极致零延迟的头部骨骼解算。
public class AirPodsMotionManager: ObservableObject {
    private let motionManager = CMHeadphoneMotionManager()
    
    @Published public var isTracking: Bool = false
    @Published public var pitch: Double = 0.0
    @Published public var yaw: Double = 0.0
    @Published public var roll: Double = 0.0
    
    public init() {}
    
    /// 启动 AirPods 空间追踪
    public func startTracking() {
        guard motionManager.isDeviceMotionAvailable else {
            print("❌ 此设备不支持 CMHeadphoneMotion (请确保佩戴 AirPods)")
            return
        }
        
        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] (motion, error) in
            guard let self = self, let motion = motion, error == nil else { return }
            
            self.isTracking = true
            
            // 获取头部欧拉角 (在实战中通常使用四元数 motion.attitude.quaternion 发送给算法端)
            self.pitch = motion.attitude.pitch
            self.yaw = motion.attitude.yaw
            self.roll = motion.attitude.roll
            
            // TODO: 在这里可以将这三个姿态数值打包成另一种极轻量的 JSON 或 UDP Packet，
            // 喷射给 PC 端 Mac 的山茶花骨骼 IK 引擎。
        }
    }
    
    public func stopTracking() {
        motionManager.stopDeviceMotionUpdates()
        self.isTracking = false
    }
}
