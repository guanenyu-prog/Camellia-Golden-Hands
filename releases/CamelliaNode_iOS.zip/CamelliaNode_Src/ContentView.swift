import SwiftUI

struct ContentView: View {
    @StateObject private var depthManager = DepthCameraManager()
    @StateObject private var networkStreamer = NetworkStreamer()
    @StateObject private var airpodsManager = AirPodsMotionManager()
    
    @State private var targetIP: String = "192.168.1.100" // 默认接收端 (PC/Mac) IP
    @State private var nodeIdStr: String = "1"
    @State private var isFrontCamera: Bool = true // 控制前后置切换
    
    var body: some View {
        VStack(spacing: 20) {
            // Header
            VStack(spacing: 5) {
                Text("Camellia Node")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                Text("V11 Data Pump (CBS Protocol)")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            .padding(.top, 40)
            
            // Network Config
            GroupBox(label: Text("Networking (MLO / USBMUXD)")) {
                VStack {
                    HStack {
                        Text("Target IP:")
                        TextField("e.g. 192.168.1.100", text: $targetIP)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numbersAndPunctuation)
                    }
                    HStack {
                        Text("Node ID:")
                        TextField("e.g. 1 (Left), 2 (Right)", text: $nodeIdStr)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .keyboardType(.numberPad)
                            .onChange(of: nodeIdStr) { newValue in
                                if let id = UInt8(newValue) {
                                    depthManager.assignedNodeId = id
                                }
                            }
                    }
                    
                    HStack {
                        Circle()
                            .fill(networkStreamer.isConnected ? Color.green : Color.red)
                            .frame(width: 10, height: 10)
                        Text(networkStreamer.isConnected ? "UDP Connected" : "Disconnected")
                            .font(.subheadline)
                        
                        Spacer()
                        
                        Button(action: {
                            if networkStreamer.isConnected {
                                networkStreamer.disconnect()
                            } else {
                                networkStreamer.connect(to: targetIP)
                                // 将 streamer 挂载给 depthManager
                                depthManager.networkStreamer = networkStreamer
                            }
                        }) {
                            Text(networkStreamer.isConnected ? "Disconnect" : "Connect")
                                .bold()
                                .frame(width: 100)
                                .padding(8)
                                .background(networkStreamer.isConnected ? Color.red : Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                    .padding(.top, 5)
                }
            }
            .padding(.horizontal)
            
            // Sensors
            GroupBox(label: Text("Sensors Status")) {
                VStack(spacing: 15) {
                    // Depth Status
                    // Camera Selection & Depth Status
                    HStack {
                        VStack(alignment: .leading) {
                            Text("16-bit Depth Matrix")
                                .bold()
                            Text(depthManager.isRunning ? "FPS: \(String(format: "%.1f", depthManager.currentFPS))" : "FPS: 0.0")
                                .font(.caption)
                        }
                        
                        Spacer()
                        
                        VStack {
                            Picker("Camera", selection: $isFrontCamera) {
                                Text("Front (TrueDepth)").tag(true)
                                Text("Rear (LiDAR)").tag(false)
                            }
                            .pickerStyle(SegmentedPickerStyle())
                            .disabled(depthManager.isRunning) // 运行时禁止切换
                            .frame(width: 180)
                            
                            Button(action: {
                                if depthManager.isRunning {
                                    depthManager.stop()
                                } else {
                                    if isFrontCamera {
                                        depthManager.startTrueDepth()
                                    } else {
                                        depthManager.startLiDAR()
                                    }
                                }
                            }) {
                                Text(depthManager.isRunning ? "Stop" : "Start Stream")
                                    .bold()
                                    .frame(width: 160)
                                    .padding(8)
                                    .background(depthManager.isRunning ? Color.orange : Color.green)
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                            }
                        }
                    }
                    
                    Divider()
                    
                    // AirPods Status
                    HStack {
                        VStack(alignment: .leading) {
                            Text("AirPods IMU")
                                .bold()
                            Text(airpodsManager.isTracking ? "P:\(String(format: "%.1f", airpodsManager.pitch)) Y:\(String(format: "%.1f", airpodsManager.yaw)) R:\(String(format: "%.1f", airpodsManager.roll))" : "Off")
                                .font(.caption)
                        }
                        
                        Spacer()
                        
                        Button(action: {
                            if airpodsManager.isTracking {
                                airpodsManager.stopTracking()
                            } else {
                                airpodsManager.startTracking()
                            }
                        }) {
                            Text(airpodsManager.isTracking ? "Stop" : "Start IMU")
                                .frame(width: 100)
                                .padding(8)
                                .background(airpodsManager.isTracking ? Color.orange : Color.purple)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                }
            }
            .padding(.horizontal)
            
            // Telemetry Stats
            VStack {
                Text("Bytes Sent: \(networkStreamer.bytesSent / 1024 / 1024) MB")
                    .font(.footnote)
                    .foregroundColor(.gray)
            }
            .padding(.top, 20)
            
            Spacer()
        }
        .onAppear {
            // 防止手机熄屏：禁用自动锁屏
            UIApplication.shared.isIdleTimerDisabled = true
        }
        .onDisappear {
            UIApplication.shared.isIdleTimerDisabled = false
            depthManager.stop()
            networkStreamer.disconnect()
            airpodsManager.stopTracking()
        }
    }
}
