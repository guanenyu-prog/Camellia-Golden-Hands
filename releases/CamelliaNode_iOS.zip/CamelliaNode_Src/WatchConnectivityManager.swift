import Foundation
import WatchConnectivity

/// 负责在 iOS (iPhone) 端接收来自 Apple Watch 的高频 IMU 与手势数据，
/// 并将其推入已有的 NetworkStreamer 发射给 PC/Mac中枢。
public class WatchConnectivityManager: NSObject, ObservableObject {
    public static let shared = WatchConnectivityManager()
    
    @Published public var isWatchReachable: Bool = false
    @Published public var lastReceivedCommand: String = "None"
    
    /// 注入网络流媒体模块，用于数据转发
    public var networkStreamer: NetworkStreamer?
    
    private override init() {
        super.init()
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
    }
    
    /// 触发手表端的 Taptic Engine (通过 iPhone 发送反馈指令)
    public func triggerWatchHaptics(type: String = "success") {
        guard WCSession.default.isReachable else { return }
        let message = ["command": "trigger_haptic", "type": type]
        WCSession.default.sendMessage(message, replyHandler: nil) { error in
            print("❌ 向 Watch 发送震动指令失败: \(error)")
        }
    }
}

extension WatchConnectivityManager: WCSessionDelegate {
    public func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        DispatchQueue.main.async {
            self.isWatchReachable = session.isReachable
        }
    }
    
    public func sessionDidBecomeInactive(_ session: WCSession) { }
    
    public func sessionDidDeactivate(_ session: WCSession) {
        WCSession.default.activate()
    }
    
    public func sessionReachabilityDidChange(_ session: WCSession) {
        DispatchQueue.main.async {
            self.isWatchReachable = session.isReachable
        }
    }
    
    /// 核心：接收 Watch 高频发来的手势和姿态数据
    public func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        if let gesture = message["gesture"] as? String {
            DispatchQueue.main.async {
                self.lastReceivedCommand = gesture
            }
            
            // TODO: 在这里将接收到的 Double Pinch 或 IMU 四元数，
            // 封装进 CBSProtocol 的拓展体中，调用 networkStreamer?.send(...) 射给 PC。
            print("⌚️ 收到手表指令: \(gesture)")
        }
    }
}
