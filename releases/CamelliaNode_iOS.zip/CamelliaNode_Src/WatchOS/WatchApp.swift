import SwiftUI

@main
struct WatchApp: App {
    var body: some Scene {
        WindowGroup {
            WatchContentView()
                // 手表端强制暗黑模式以节省 OLED 电量
                .preferredColorScheme(.dark)
        }
    }
}
