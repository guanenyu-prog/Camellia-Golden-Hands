import Foundation
import CoreMotion
import WatchConnectivity
import WatchKit

/// 负责在手表端读取高频 IMU 和微手势，并通过蓝牙发送给 iPhone
public class WatchMotionManager: NSObject, ObservableObject {
    private let motionManager = CMMotionManager()
    
    @Published public var isTracking: Bool = false
    @Published public var pitch: Double = 0.0
    @Published public var roll: Double = 0.0
    @Published public var yaw: Double = 0.0
    
    public override init() {
        super.init()
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
    }
    
    public func startTracking() {
        guard motionManager.isDeviceMotionAvailable else { return }
        
        // 设置极高刷新率 (实战中 60Hz，即 0.016)
        motionManager.deviceMotionUpdateInterval = 1.0 / 60.0
        
        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] (motion, error) in
            guard let self = self, let motion = motion else { return }
            
            self.isTracking = true
            self.pitch = motion.attitude.pitch
            self.roll = motion.attitude.roll
            self.yaw = motion.attitude.yaw
            
            // 检测类似 Double Pinch (捏合) 的极速加速度尖峰特征
            // （这里是一个简化的高通滤波逻辑，苹果原生的 Pinch API 在某些版本受限，用加速度阈值判定非常可靠）
            let userAccel = motion.userAcceleration
            let accelMagnitude = sqrt(pow(userAccel.x, 2) + pow(userAccel.y, 2) + pow(userAccel.z, 2))
            
            if accelMagnitude > 2.5 { // 突然的微手势激振
                self.sendGestureToiPhone(gestureType: "DoublePinch")
            }
            
            // TODO: 在这里也可以按照一定频率（如 30Hz）将欧拉角发送给 iPhone
        }
    }
    
    public func stopTracking() {
        motionManager.stopDeviceMotionUpdates()
        self.isTracking = false
    }
    
    private func sendGestureToiPhone(gestureType: String) {
        guard WCSession.default.isReachable else { return }
        let payload = ["gesture": gestureType, "timestamp": Date().timeIntervalSince1970] as [String : Any]
        WCSession.default.sendMessage(payload, replyHandler: nil, errorHandler: nil)
        
        // 本地触发一个小震动，告诉演员“指令已发出”
        WKInterfaceDevice.current().play(.click)
    }
}

extension WatchMotionManager: WCSessionDelegate {
    public func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {}
    
    /// 监听来自 iPhone (即来自 PC 端) 的反向触感反馈指令
    public func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        if let command = message["command"] as? String, command == "trigger_haptic" {
            DispatchQueue.main.async {
                // 比如玩家在引擎里摸到了虚拟墙壁，手表立刻震动
                WKInterfaceDevice.current().play(.success)
            }
        }
    }
}
