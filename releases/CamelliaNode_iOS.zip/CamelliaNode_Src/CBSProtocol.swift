import Foundation
import simd

/// 山茶花二进制流协议 (Camellia Binary Stream - CBS) V2 (含 RGB)
public struct CamelliaDepthPacket {
    public let magicHeader: UInt32 = 0x43414D45 // "CAME"
    public var nodeId: UInt8
    public var timestampUs: UInt64
    public var intrinsics: simd_float3x3
    
    /// JPEG 压缩格式的 RGB 彩色画面流
    public var rgbData: Data
    
    /// 16-bit 原生深度数据数组 (以 Data 形式零拷贝挂载)
    public var depthData: Data
    
    public func serialize() -> Data {
        var data = Data()
        var magic = magicHeader.littleEndian
        data.append(withUnsafeBytes(of: &magic) { Data($0) })
        data.append(nodeId)
        
        var ts = timestampUs.littleEndian
        data.append(withUnsafeBytes(of: &ts) { Data($0) })
        
        let cols = intrinsics.columns
        var flatIntrinsics: [Float32] = [
            cols.0.x, cols.0.y, cols.0.z,
            cols.1.x, cols.1.y, cols.1.z,
            cols.2.x, cols.2.y, cols.2.z
        ]
        flatIntrinsics.withUnsafeBufferPointer { buffer in
            data.append(buffer)
        }
        
        // 写入 RGB Payload 大小 (4 bytes)
        var rgbSize = UInt32(rgbData.count).littleEndian
        data.append(withUnsafeBytes(of: &rgbSize) { Data($0) })
        
        // 写入 RGB 数据
        data.append(rgbData)
        
        // 写入 Depth Payload 大小 (4 bytes)
        var depthSize = UInt32(depthData.count).littleEndian
        data.append(withUnsafeBytes(of: &depthSize) { Data($0) })
        
        // 写入 16-bit 深度数组
        data.append(depthData)
        
        return data
    }
}

/// 山茶花运动学融合协议 (Camellia Kinematic Stream) V11+
/// 用于传输高频的 IMU、视觉骨骼拓扑和物理绝对锚点（轻量化 JSON 序列化，专为 Python Chaos Engine 设计）
public struct CamelliaKinematicPacket: Codable {
    public var magicHeader: String = "C_KIN"
    public var nodeId: String           // 节点身份：例如 "iPhone_Hilt" (剑柄), "iPhone_Face" (面部)
    public var timestampMs: UInt64      // 极高频时间戳，用于多机位时钟对齐
    
    // 1. 绝对锚点定位 (TrueDepth / UWB / Mac Lid Angle)
    public struct SpatialAnchor: Codable {
        public var isActive: Bool
        public var anchorType: String   // "UWB_U1", "TRUEDEPTH", "LID_ANGLE"
        public var absoluteXYZ: [Float]? // [x, y, z] 绝对空间坐标
        public var relativeDistance: Float?
    }
    public var anchor: SpatialAnchor?
    
    // 2. 惯性导航真理 (极高频，光剑引擎核心)
    public struct IMUKinematics: Codable {
        public var pitch: Float
        public var yaw: Float
        public var roll: Float
        public var accelerationXYZ: [Float] // [x, y, z] 用于瞬间加速度（防滑步硬截断）
    }
    public var imu: IMUKinematics?
    
    // 3. 无量纲视觉拓扑 (21 点手部 / 52表情通道)
    public struct VisionTopology: Codable {
        public struct Point: Codable {
            public var id: Int
            public var x: Float
            public var y: Float
            public var z: Float         // 相对比例 Z，非绝对深度
            public var confidence: Float
        }
        public var leftHand: [Point]?
        public var rightHand: [Point]?
        public var faceBlendshapes: [String: Float]? // 原生替代 Live Link Face
    }
    public var vision: VisionTopology?
    
    public func toJSON() -> Data? {
        let encoder = JSONEncoder()
        return try? encoder.encode(self)
    }
}
