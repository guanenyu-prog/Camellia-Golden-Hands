import SwiftUI
import WatchKit

struct WatchContentView: View {
    @StateObject private var motionManager = WatchMotionManager()
    
    var body: some View {
        VStack {
            Spacer()
            
            // 状态显示球
            Circle()
                .fill(motionManager.isTracking ? Color.green : Color.gray)
                .frame(width: 80, height: 80)
                .overlay(
                    Text(motionManager.isTracking ? "LIVE" : "READY")
                        .font(.headline)
                        .foregroundColor(.white)
                )
                .shadow(color: motionManager.isTracking ? .green : .clear, radius: 10, x: 0, y: 0)
                .onTapGesture {
                    if motionManager.isTracking {
                        motionManager.stopTracking()
                    } else {
                        motionManager.startTracking()
                    }
                }
            
            Spacer()
            
            // 数据预览
            if motionManager.isTracking {
                VStack(spacing: 4) {
                    Text("Pitch: \(String(format: "%.2f", motionManager.pitch))")
                    Text("Roll: \(String(format: "%.2f", motionManager.roll))")
                    Text("Yaw: \(String(format: "%.2f", motionManager.yaw))")
                }
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(.cyan)
            } else {
                Text("Tap to Start Camellia Tracker")
                    .font(.footnote)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            // 触感测试按钮 (反向测试从 PC 发来的震动指令)
            Button(action: {
                WKInterfaceDevice.current().play(.success)
            }) {
                Text("Test Haptics")
                    .font(.caption2)
            }
            .tint(.orange)
            .padding(.bottom, 5)
        }
    }
}
