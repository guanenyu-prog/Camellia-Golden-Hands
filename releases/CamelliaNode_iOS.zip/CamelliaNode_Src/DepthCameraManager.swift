import Foundation
import AVFoundation
import CoreVideo
import simd
import UIKit
import Accelerate

/// 原生深度与RGB抓取器，直接提取 AVFoundation 的 16-bit 深度流与高清 RGB 并强制同步
public class DepthCameraManager: NSObject, ObservableObject {
    private let captureSession = AVCaptureSession()
    private let depthDataOutput = AVCaptureDepthDataOutput()
    private let videoDataOutput = AVCaptureVideoDataOutput()
    private var outputSynchronizer: AVCaptureDataOutputSynchronizer?
    
    private let sessionQueue = DispatchQueue(label: "com.camellia.depth_session", qos: .userInteractive)
    private let dataOutputQueue = DispatchQueue(label: "com.camellia.data_output", qos: .userInteractive)
    
    // 【性能绝杀修复】：CIContext 全局唯一单例复用，消灭每帧 50ms 初始化开销
    private let ciContext = CIContext(options: [CIContextOption.useSoftwareRenderer: false])
    
    public var networkStreamer: NetworkStreamer?
    public var assignedNodeId: UInt8 = 0x01
    
    @Published public var isRunning: Bool = false
    @Published public var currentFPS: Double = 0.0
    
    private var lastFrameTime = Date()
    private var frameCount = 0
    
    public override init() {
        super.init()
    }
    
    public func startTrueDepth() {
        sessionQueue.async {
            self.configureSession(position: .front)
            self.captureSession.startRunning()
            DispatchQueue.main.async { self.isRunning = true }
        }
    }
    
    public func startLiDAR() {
        sessionQueue.async {
            self.configureSession(position: .back)
            self.captureSession.startRunning()
            DispatchQueue.main.async { self.isRunning = true }
        }
    }
    
    public func stop() {
        sessionQueue.async {
            self.captureSession.stopRunning()
            DispatchQueue.main.async { self.isRunning = false }
        }
    }
    
    private func configureSession(position: AVCaptureDevice.Position) {
        captureSession.beginConfiguration()
        
        // 清理旧的输入输出，支持无缝前后置切换
        for input in captureSession.inputs {
            captureSession.removeInput(input)
        }
        for output in captureSession.outputs {
            captureSession.removeOutput(output)
        }
        
        captureSession.sessionPreset = .vga640x480
        
        // 100% 对齐 Record3D 标准：使用 DiscoverySession 扫描支持深度的前后置镜头
        let deviceTypes: [AVCaptureDevice.DeviceType] = (position == .front)
            ? [.builtInTrueDepthCamera, .builtInWideAngleCamera]
            : [.builtInLiDARDepthCamera, .builtInDualWideCamera, .builtInTripleCamera, .builtInWideAngleCamera]
        
        let discovery = AVCaptureDevice.DiscoverySession(
            deviceTypes: deviceTypes,
            mediaType: .video,
            position: position
        )
        
        guard let camera = discovery.devices.first else {
            print("❌ 找不到支持深度的相机设备 (position: \(position == .front ? "front" : "back"))")
            captureSession.commitConfiguration()
            return
        }
        
        do {
            // 显式激活后置/前置最佳支持的深度格式
            try camera.lockForConfiguration()
            let depthFormats = camera.activeFormat.supportedDepthDataFormats
            if let targetDepthFormat = depthFormats.first(where: {
                CMFormatDescriptionGetMediaSubType($0.formatDescription) == kCVPixelFormatType_DepthFloat32 ||
                CMFormatDescriptionGetMediaSubType($0.formatDescription) == kCVPixelFormatType_DepthFloat16
            }) ?? depthFormats.first {
                camera.activeDepthDataFormat = targetDepthFormat
            }
            camera.unlockForConfiguration()
            
            let input = try AVCaptureDeviceInput(device: camera)
            if captureSession.canAddInput(input) { captureSession.addInput(input) }
            
            // 1. 配置 RGB 输出
            videoDataOutput.videoSettings = [kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32BGRA)]
            if captureSession.canAddOutput(videoDataOutput) {
                captureSession.addOutput(videoDataOutput)
            }
            
            // 2. 配置 Depth 输出 (对齐 Record3D: 开启底层硬件双边滤波)
            depthDataOutput.isFilteringEnabled = true
            if captureSession.canAddOutput(depthDataOutput) {
                captureSession.addOutput(depthDataOutput)
            }
            if let depthConnection = depthDataOutput.connection(with: .depthData) {
                depthConnection.isEnabled = true
            }
            
            // 3. 配置硬件级同步器 (V11 物理对齐的灵魂)
            outputSynchronizer = AVCaptureDataOutputSynchronizer(dataOutputs: [videoDataOutput, depthDataOutput])
            outputSynchronizer?.setDelegate(self, queue: dataOutputQueue)
            
        } catch {
            print("❌ 开启相机失败: \(error)")
        }
        
        captureSession.commitConfiguration()
    }
}

extension DepthCameraManager: AVCaptureDataOutputSynchronizerDelegate {
    public func dataOutputSynchronizer(_ synchronizer: AVCaptureDataOutputSynchronizer, didOutput synchronizedDataCollection: AVCaptureSynchronizedDataCollection) {
        
        // 提取完全对齐的 RGB 和 Depth
        guard let syncedVideoData = synchronizedDataCollection.synchronizedData(for: videoDataOutput) as? AVCaptureSynchronizedSampleBufferData,
              let syncedDepthData = synchronizedDataCollection.synchronizedData(for: depthDataOutput) as? AVCaptureSynchronizedDepthData,
              !syncedVideoData.sampleBufferWasDropped, !syncedDepthData.depthDataWasDropped else {
            return
        }
        
        let sampleBuffer = syncedVideoData.sampleBuffer
        var depthData = syncedDepthData.depthData
        
        // 100% 对齐 Record3D 标准：强制转为 Float32 米制深度 (彻底杜绝视差单位错误)
        if depthData.depthDataType != kCVPixelFormatType_DepthFloat32 {
            depthData = depthData.converting(toDepthDataType: kCVPixelFormatType_DepthFloat32)
        }
        
        // 【对齐 Record3D 标准】：将深度矩阵物理转置为竖屏 (Portrait 480x640)
        depthData = depthData.applyingExifOrientation(.right)
        
        // 提取 CVPixelBuffer
        guard let videoPixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        let depthPixelBuffer = depthData.depthDataMap
        
        // --- 1. 处理 RGB 画面 (对齐 Record3D 标准: 转置为竖屏并压缩 JPEG) ---
        let ciImage = CIImage(cvPixelBuffer: videoPixelBuffer).oriented(.right)
        guard let cgImage = ciContext.createCGImage(ciImage, from: ciImage.extent) else { return }
        let uiImage = UIImage(cgImage: cgImage)
        // 使用 0.6 压缩率平衡清晰度与带宽
        guard let jpegData = uiImage.jpegData(compressionQuality: 0.6) else { return }
        
        // --- 2. 100% 对齐 Record3D: 硬件 SIMD 双线性插值输出 480x640 Float32 密集米制深度流 ---
        let intrinsics = depthData.cameraCalibrationData?.intrinsicMatrix ?? matrix_identity_float3x3
        
        let targetW = 480
        let targetH = 640
        
        CVPixelBufferLockBaseAddress(depthPixelBuffer, .readOnly)
        guard let baseAddress = CVPixelBufferGetBaseAddress(depthPixelBuffer) else {
            CVPixelBufferUnlockBaseAddress(depthPixelBuffer, .readOnly)
            return
        }
        
        let srcW = CVPixelBufferGetWidth(depthPixelBuffer)
        let srcH = CVPixelBufferGetHeight(depthPixelBuffer)
        let srcBytesPerRow = CVPixelBufferGetBytesPerRow(depthPixelBuffer)
        
        var srcBuffer = vImage_Buffer(
            data: baseAddress,
            height: vImagePixelCount(srcH),
            width: vImagePixelCount(srcW),
            rowBytes: srcBytesPerRow
        )
        
        var float32Data = Data(count: targetW * targetH * MemoryLayout<Float32>.size)
        float32Data.withUnsafeMutableBytes { dstPtr in
            guard let dstBase = dstPtr.baseAddress else { return }
            var dstBuffer = vImage_Buffer(
                data: dstBase,
                height: vImagePixelCount(targetH),
                width: vImagePixelCount(targetW),
                rowBytes: targetW * MemoryLayout<Float32>.size
            )
            vImageScale_PlanarF(&srcBuffer, &dstBuffer, nil, vImage_Flags(kvImageHighQualityResampling))
        }
        CVPixelBufferUnlockBaseAddress(depthPixelBuffer, .readOnly)
        
        // 计算 FPS
        let now = Date()
        frameCount += 1
        if now.timeIntervalSince(lastFrameTime) >= 1.0 {
            let fps = Double(frameCount) / now.timeIntervalSince(lastFrameTime)
            DispatchQueue.main.async { self.currentFPS = fps }
            frameCount = 0
            lastFrameTime = now
        }
        
        // 微秒级硬件时间戳
        let tsUs = UInt64(syncedVideoData.timestamp.seconds * 1_000_000)
        
        let packet = CamelliaDepthPacket(
            nodeId: assignedNodeId,
            timestampUs: tsUs,
            intrinsics: intrinsics,
            rgbData: jpegData,
            depthData: float32Data
        )
        
        networkStreamer?.sendPacket(packet)
    }
}
