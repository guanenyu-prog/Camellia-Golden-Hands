import SwiftUI

@main
struct CamelliaNodeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                // 强制暗黑模式以符合工业软件调性并降低功耗
                .preferredColorScheme(.dark)
        }
    }
}
