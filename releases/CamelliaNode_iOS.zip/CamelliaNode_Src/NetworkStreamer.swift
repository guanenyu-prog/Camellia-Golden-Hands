import Foundation
import Network

/// TCP 数据泵喷射器，用于 Wi-Fi 7 MLO 和 本地 USBMUXD 通道 (支持大包传输)
public class NetworkStreamer: ObservableObject {
    private var connection: NWConnection?
    private let queue = DispatchQueue(label: "com.camellia.network", qos: .userInteractive)
    
    @Published public var isConnected: Bool = false
    @Published public var bytesSent: Int64 = 0
    
    private var isSending: Bool = false
    
    public init() {}
    
    /// 连接到 Mac 中枢
    /// - Parameters:
    ///   - host: IP 地址 (如果是 USBMUXD，就是局域网网关；如果是 Wi-Fi，就是 Mac 的 IP)
    ///   - port: 端口号，默认 8765
    public func connect(to host: String, port: UInt16 = 8765) {
        let endpoint = NWEndpoint.hostPort(host: NWEndpoint.Host(host), port: NWEndpoint.Port(integerLiteral: port))
        
        // 改用 TCP 协议：因为 RGB+Depth 单帧数据超过 500KB，远超 UDP 64KB 极限。
        // USBMUXD 本质上也是 TCP 端口转发。
        let parameters = NWParameters.tcp
        
        connection = NWConnection(to: endpoint, using: parameters)
        
        connection?.stateUpdateHandler = { [weak self] state in
            DispatchQueue.main.async {
                switch state {
                case .ready:
                    self?.isConnected = true
                    print("🚀 Camellia Network Streamer Ready at \(host):\(port)")
                case .failed(let error):
                    self?.isConnected = false
                    print("❌ Camellia Network Error: \(error)")
                case .cancelled:
                    self?.isConnected = false
                default:
                    break
                }
            }
        }
        
        connection?.start(queue: queue)
    }
    
    public func disconnect() {
        connection?.cancel()
        connection = nil
        isSending = false
    }
    
    /// 将封装好的 CBS 深度协议包通过 TCP 发射出去
    /// 【对齐 Record3D 核心机制】：背压防积压丢帧。上一帧未发完前，直接丢弃新帧，保证发出的永远是手机当前最新一帧！
    public func sendPacket(_ packet: CamelliaDepthPacket) {
        guard let connection = connection, connection.state == .ready else { return }
        
        // 如果网络缓冲区还在发送上一帧，直接丢弃当前帧，消灭 2~5 秒排队延迟！
        if isSending { return }
        isSending = true
        
        let payload = packet.serialize()
        
        connection.send(content: payload, completion: .contentProcessed { [weak self] error in
            self?.isSending = false
            if let error = error {
                print("发送失败: \(error)")
            } else {
                DispatchQueue.main.async {
                    self?.bytesSent += Int64(payload.count)
                }
            }
        })
    }
}
